# camtrap
Inference for campera trap data
